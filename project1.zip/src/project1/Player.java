/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;
public class Player {

	int playerType;
	int points;
	boolean hasTurn;
	
	public Player(int p)
	{
		this.playerType = p;
		this.points = 0;
		this.hasTurn = false;
	}
	public void setType(int i)
	{
		this.playerType = i;
	}
	
	public void switchTurn()
	{
		if(this.hasTurn)
		{
			this.hasTurn = false;
		}
		else
		{
			this.hasTurn = true;
		}
		
		//System.out.println("Player " + this.playerType + "  is now " + this.hasTurn);
	}
	
	public void setTurn(Boolean turn)
	{
		this.hasTurn = turn;
	}
	
	public boolean getHasTurn()
	{
		return this.hasTurn;
	}
	
	public void scorePoints()
	{
		this.points += 1;
	}
	
	public int getScore()
	{
		return this.points;
	}
}

